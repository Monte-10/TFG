# tfgtfmthesisuam

Este estilo está pensado como plantilla para la creación de los documentos de TFG, TFM y tesis de la Escuela Politécnica Superior.

Está pensado para que pueda ser modificado por cualquier usuario, ampliándolo con más funcionalidades, mejorando el código, la documentación o corrigiendo errores.

Una vez modificado se solicita el merge de los cambios para que sea actualizado el estilo.
